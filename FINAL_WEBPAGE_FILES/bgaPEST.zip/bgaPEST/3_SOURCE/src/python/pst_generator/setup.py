# /usr/local/bin/python

'''
py2exe driver for making pst_generator.py into an executable for windows
'''

from distutils.core import setup
import py2exe

